#1). Run the following code in R-studio to create two variables X and Y.
set.seed(2017)
X=runif(100)*10
Y=X*4+3.45
Y=rnorm(100)*0.29*Y+Y
#a) Plot Y against X. Include a screenshot of the plot in your submission. Using the File menu you 
#can save the graph as a picture on your computer. Based on the plot do you think we can fit a 
#linear model to explain Y based on X?

plot(X,Y)

#Inorder to check if we can fit the linear model

cor(X,Y)

#We can fit the linear Model as the correlation is positive, 

#b) Construct a simple linear model of Y based on X. Write the equation that explains Y based on 
#X. What is the accuracy of this model?

LinearModel<- lm(Y~X)
summary(LinearModel)

#The equation for the model is Y = 3.61*X + 4.46
#Hence the Accuracy for Bravo Model is 65%


#c) How the Coefficient of Determinaation, R2, of the model above is related to the correlation coefficient of X and Y? (

Coefficient_Determination<- (cor(Y,X))^2
Coefficient_Determination


#2) We will use the 'mtcars' dataset for this question. The dataset is already included in your R 
#distribution. The dataset shows some of the characteristics of different cars. The following shows 
#few samples (i.e. the first 6 rows) of the dataset. The description of the dataset can be found here.

head(mtcars)

#a)James wants to buy a car. He and his friend, Chris, have different opinions about the Horse Power (hp) of cars. James think the weight of a car (wt) can be used to estimate the Horse 
#Power of the car while Chris thinks the fuel consumption expressed in Mile Per Gallon (mpg), is a better estimator of the (hp). Who do you think is right? Construct simple linear models 
#using mtcars data to answer the question

LinearModel2<- lm(hp ~ wt, date = mtcars)#HP=HorsePower,wt=Weight
summary(LinearModel2)

LinearModel3<- lm(formula = hp ~ mpg, data = mtcars) #hp=horsepoer, mpg=Mile per Gallon
summary(LinearModel3)

#b) Build a model that uses the number of cylinders (cyl) and the mile per gallon (mpg) values of a car to predict the car Horse Power (hp). Using this model, what is the estimated Horse Power 
#of a car with 4 calendar and mpg of 22?

LinearModel4<- lm(hp ~cy1+mpg, data = mtcars)
summary(LinearModel4)

#Predict the HP with 4 cylinder and mpg of 22:

Predict_LinearModel4 <- predict(LinearModel4,data.frame(cy1=4, mpg=22), interval = 'prediction')
Predict_LinearModel4

#3. For this question, we are going to use BostonHousing dataset. The dataset is in 'mlbench' package, so we first need to instal the package, call the library and the load the dataset using the following commands
install.packages('mlbench')
library(mlbench)
data(BostonHousing)
#You should have a dataframe with the name of BostonHousing in your Global environment now The dataset contains information about houses in different parts of Boston. Details of the dataset 
#is explained here. Note the dataset is old, hence low house prices!


#a) Build a model to estimate the median value of owner-occupied homes (medv)based on the following variables: crime crate (crim), proportion of residential land zoned for lots over 
#25,000 sq.ft (zn), the local pupil-teacher ratio (ptratio) and weather the whether the tract bounds Chas River(chas). Is this an accurate model? (Hint check R)

HousingModel <- lm(medv ~ crim +zn+ptratio+chas, data = BostonHousing)
HousingModel

#b) Use the estimated coefficient to answer these questions? 

# I. Imagine two houses that are identical in all aspects but one bounds the Chas River and the other does not. Which one is more expensive and by how much?
HousingModel1<- lm(medv~chas, data = BostonHousing)

# To find expensive house with chas valus pf 1 and 0:
#For chas = 0
chas_value1<- (HousingModel1$coefficient[2]*0) + HousingModel1$coefficient[1]
chas_value1

#For chas = 1
chas_value2<- (HousingModel1$coefficient[2]*1) + HousingModel1$coefficient[1]
chas_value2

#II. Imagine two houses that are identical in all aspects but in the neighborhood of one of them the pupil-teacher ratio is 15 and in the other one is 18. Which one is more expensive and by how much? 
HousingModel2<-lm(medv ~ ptratio, data = BostonHousing)
summary(HousingModel2)

# Neighborhood with the pupil-teacher ratio = 15

ptratio1 <- (HousingModel2$coefficients[2] * 15) + HousingModel2$coefficients[1]
ptratio1

# Neighborhood with the pupil-teacher ratio = 18

ptratio2 <- (HousingModel2$coefficients[2] * 18) + HousingModel2$coefficients[1]
ptratio2

#Here we can se that the coefficients are negative which means that with the increase in ptratio the housing prices will decrease.
#This is clear in the above estimation, which says that the price of house with the ptratio of 15 (29.986998) is higher as compared to the house with the ptratio of 18(23.5154721) by value (6.4715259)


#c) Which of the variables are statistically important (i.e. related to the house price)? Hint: use the p-values of the coefficients to answer.

summary(HousingModel)
#As the P va;ues are low, we are rejecting the null-hyothesis which says that variable are statistically 

#As we know that the low value of null hypothesis indicates that we can reject the null hypothesis. So after looking at the p-values we can say that none of the independent variables are statistically insignificant.

#d) Use the anova analysis and determine the order of importance of these four variables. 

anova(HousingModel)

#After careful analysis of the anova values we can say that the variables in the order of their importance (From High to Low) are :
#crim - 6440.7830587
#ptratio - 4709.5358422
#zn - 3554.3361972
#chas - 667.1868051











