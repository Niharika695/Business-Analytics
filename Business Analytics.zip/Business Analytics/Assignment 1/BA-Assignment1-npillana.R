library(dplyr)
library(scales)
library(gapminder)

setwd("C:/Users/nihar/Desktop/Assignment/Business Analytics/Assignment 1")

#importing dataset
library(readr)
Online_Retail <- read_csv("Online_Retail.csv")

# 1.	Show the breakdown of the number of transactions by countries i.e. how many transactions are in the dataset for each country (consider all records including cancelled transactions). 
#Show this in total number and also in percentage. Show only countries accounting for more than 1% of the total transactions. (5 marks) 

colnames(Online_Retail)
table(Online_Retail$Country)
OR<- summarise(group_by(Online_Retail,Country), count=n())
OR1<-as.data.frame(OR)
OR2<-select(OR1, count)
Percent<-(OR2/sum(OR2))*100
OR3<-cbind(OR1,Percent)
names(OR3)[3]<-"percentage"
filter(OR3, Percent>1)

# 2.	Create a new variable 'TransactionValue' that is the product of the exising 'Quantity' and 'UnitPrice' variables. Add this variable to the dataframe. (5 marks) 
#creating new variable which is a product of quantity and Unitprice
TransactionValue<- Online_Retail$Quantity*Online_Retail$UnitPrice
TV <- cbind(Online_Retail, TransactionValue)
head(TV)

# 3.	Using the newly created variable, TransactionValue, show the breakdown of transaction values by countries i.e. how much money in total has been spent each country. Show this in total sum of transaction values. Show only countries with total transaction exceeding 130,000 British Pound. (10 marks) 
library(gapminder)
OR4<-(summarise(group_by(TV,Country),totalsum=sum(TransactionValue))%>%filter(totalsum>13000))
OR5<- as.data.frame(OR4)
OR5

# 4.	This is an optional question which carries additional marks (golden questions). In this question, we are dealing with the InvoiceDate variable. The variable is read as a categorical when you read data from the file. Now we need to explicitly instruct R to interpret this as a Date variable. "POSIXlt" and "POSIXct" are two powerful object classes in R to deal with date and time. Click here for more information.  First let's convert 'InvoiceDate' into a POSIXlt object: 
#   Temp=strptime(Online_Retail$InvoiceDate,format='%m/%d/%Y %H:%M',tz='GMT') 

# Check the variable using, head(Temp). Now, let's separate date, day of the week and hour components dataframe with names as New_Invoice_Date, Invoice_Day_Week and New_Invoice_Hour: 
#   Online_Retail$New_Invoice_Date <- as.Date(Temp) 
# The Date objects have a lot of flexible functions. For example knowing two date values, the object allows you to know the difference between the two dates in terms of the number days. Try this: 
#   Online_Retail$New_Invoice_Date[20000]- Online_Retail$New_Invoice_Date[10] 
# Also we can convert dates to days of the week. Let's define a new variable for that 
# Online_Retail$Invoice_Day_Week= weekdays(Online_Retail$New_Invoice_Date) 
# For the Hour, let's just take the hour (ignore the minute) and convert into a normal numerical value: 
#   Online_Retail$New_Invoice_Hour = as.numeric(format(Temp, "%H")) Finally, lets define the month as a separate numeric variable too: 
#   Online_Retail$New_Invoice_Month = as.numeric(format(Temp, "%m")) 

Temp=strptime(Online_Retail$InvoiceDate,format='%m/%d/%Y %H:%M', tz='GMT')
Online_Retail$New_Invoice_Date<- as.Date(Temp)
Online_Retail$New_Invoice_Date[20000]- Online_Retail$New_Invoice_Date[10] 
#Time difference of 8 days

Online_Retail$Invoice_Day_Week= weekdays(Online_Retail$New_Invoice_Date)
Online_Retail$Invoice_Day_Hour= as.numeric(format(Temp, '%H'))
Online_Retail$Invoice_Day_Month= as.numeric(format(Temp, '%H'))
# Now answer the flowing questions. 

# a)	Show the percentage of transactions (by numbers) by days of the week (extra 2 marks) 	

Percentbyweek<-summarise(group_by(Online_Retail, Online_Retail$Invoice_Day_Week), count=n())
Percentbyweekdata<- as.data.frame(Percentbyweek)
Percentbyweekdata$count/sum(Percentbyweekdata$count)*100
 
# b)	Show the percentage of transactions (by transaction volume) by days of the week (extra 1 marks) 

tapply(Online_Retail$Quantity,Online_Retail$Invoice_Day_Week,sum)/sum(Online_Retail$Quantity)*100
 
# c)	Show the percentage of transactions (by transaction volume) by month of the year (extra 1 marks)

PercentagebyMonth<- summarise(group_by(Online_Retail, Online_Retail$Invoice_Day_Month), Sum=sum(Quantity))
PercentagebyMonthdata<- as.data.frame(PercentagebyMonth)
PercentagebyMonth$Sum/sum(PercentagebyMonth$Sum)*100

# d)	What was the date with the highest number of transactions from Australia? (3 marks)  

HighestNumber<- Online_Retail%>%filter(Country=='Australia')
HighestNumberdata<- summarise(group_by(HighestNumber,Country), high = max(Quantity))
H<-as.data.frame(HighestNumberdata)
H
filter<- filter(HighestNumber, Quantity==1152)
select(filter,Invoice_Day_Week)
 
# e)	The company needs to shut down the website for two consecutive hours for maintenance. 
#What would be the hour of the day to start this so that the distribution is at minimum for the customers? 
#The responsible IT team is available from 7:00 to 20:00 every day. (3 marks)    
library(zoo)
Maintenance<- table(Online_Retail$Invoice_Day_Hour)
Maintenance
rollapply(Maintenance, 2, sum)

# 5.	Plot the histogram of transaction values from Germany. Use the hist() function to plot. (5 marks) 

library(ISLR)
TVGermany<-select(TV,8,9)%>%filter(Country=="Germany")
hist(log(TVGermany$TransactionValue),main = "Germany Transactions",
     xlab= "Transaction Values",col = "red")

# 6.	Which customer had the highest number of transactions? Which customer is most valuable (i.e.highest total sum of transactions)? (10 marks) 

Cust.Val<- tapply(TV$TransactionValue, TV$CustomerID, length)
Cust.Val[which.max(Cust.Val)]

Cust.Value<-tapply(TV$TransactionValue, TV$CustomerID, sum)
Cust.Value[which.max(Cust.Value)]
 
# 7.	Calculate the percentage of missing values for each variable in the dataset (5 marks). Hint colMeans(): 
colMeans(is.na(Online_Retail))*100 
   
#   8.	What are the number of transactions with missing CustomerID records by countries? (10 marks) 

Missing<- function(x){
  z<-sum(is.na(x))
  return(z)
}
tapply(TV$CustomerID,TV$Country,Missing)

# 9.	On average, how often the costumers comeback to the website for their next shopping? 
#(i.e. what is the average number of days between consecutive shopping) (Optional/Golden question: 18 additional marks!) 
#Hint: 1. A close approximation is also acceptable and you may find diff() function useful.  

Comeback<- select(TV, c(5,7))
diff(Comeback$InvoiceDate, lag = 1)


# 10.	In the retail sector, it is very important to understand the return rate of the goods purchased by customers. 
#In this example, we can define this quantity, simply, as the ratio of the number of transactions cancelled (regardless of the transaction value) 
#over the total number of transactions. With this definition, what is the return rate for the French customers? (10 marks). 
#Consider the cancelled transactions as those where the 'Quantity' variable has a negative value. 

ReturnRate<- TV%>%filter(Country=="France")
NegativeReturnRate<- filter(ReturnRate, Quantity<0)
nrow(NegativeReturnRate)/nrow(ReturnRate)*100

# 11.	What is the product that has generated the highest revenue for the retailer? (i.e. item with the highest total sum of 'TransactionValue'). (10 marks) 
Revenue<- summarise(group_by(TV, Description), highvalue=sum(TransactionValue))
HighestRevenue <- as.data.frame(Revenue)
HighestRevenue[which.max(HighestRevenue$highvalue),]

# 12.	How many unique customers are represented in the dataset? You can use unique() and length() functions. (5 marks) 
length(unique(TV$CustomerID))


